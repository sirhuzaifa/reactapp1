import React from 'react'
import Appbar from '../components/Appbar'

function Home() {
  return (
    <>
    <Appbar title={"Home page"} />
    <div>Home</div>
    </>
  )
}

export default Home